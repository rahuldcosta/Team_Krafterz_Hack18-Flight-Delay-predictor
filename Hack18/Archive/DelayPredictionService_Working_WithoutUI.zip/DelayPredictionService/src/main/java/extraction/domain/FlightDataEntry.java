package extraction.domain;

public class FlightDataEntry {

    String month;
    String dayOfWeek;
    String carriercode;
    String origin;
    String dest;
    String distance;
    String delay;

    public FlightDataEntry(String month, String dayOfWeek, String carriercode, String origin, String dest,
            String distance, String delay) {
        this.month = month;
        this.dayOfWeek = dayOfWeek;
        this.carriercode = carriercode;
        this.origin = origin;
        this.dest = dest;
        this.distance = distance;
        this.delay = delay;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getCarriercode() {
        return carriercode;
    }

    public void setCarriercode(String carriercode) {
        this.carriercode = carriercode;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDest() {
        return dest;
    }

    public void setDest(String dest) {
        this.dest = dest;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getDelay() {
        return delay;
    }

    public void setDelay(String delay) {
        this.delay = delay;
    }

}
