package extraction.application.startup;

import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

import java.text.ParseException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

    public static void main(String[] args) throws ParseException {
        // String csvFile = "C:/Users/sg0224786/Desktop/scheduleData.csv";
        // FlightDataPopulator.read(csvFile);

        // Setting up classifier
        initializeClassifier();

        // Calling the Spring Application
        SpringApplication.run(Application.class, args);

    }

    private static void initializeClassifier() {
        RConnection connection = null;
        try {
            /*
             * Create a connection to Rserve instance running on default port
             * 6311
             */
            connection = new RConnection();

            connection.eval("source('C:\\\\Hack18\\\\RScripts\\\\naiveBaierAlgo.R')");
            connection.eval("initializeClassifier()");
            System.out.println("Model has intialzed with training data, Ready for prediction");
            connection.close();
            
        } catch (RserveException e) {
            e.printStackTrace();
        }
    }
}
