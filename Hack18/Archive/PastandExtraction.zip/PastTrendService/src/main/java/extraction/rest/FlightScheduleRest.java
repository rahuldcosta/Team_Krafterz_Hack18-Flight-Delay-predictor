package extraction.rest;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.web.client.RestTemplate;

import extraction.domain.Flight;
import extraction.domain.FlightSchedule;

@Named
@Path("/")
public class FlightScheduleRest {

	// private List<Flight> flights =
	// FlightDataPopulator.read("C:/Users/sg0224786/Desktop/scheduleData.csv");

	@Inject
	private RestTemplate restTemplate;

	@GET

	@Path("flightSchedule")
	@Produces(MediaType.APPLICATION_JSON)
	public List<FlightSchedule> submitOrder(@QueryParam("src") String src,
			@QueryParam("destination") String destination, @QueryParam("upto") String departureDate) {
		
		List<FlightSchedule> flightScheduleList = new ArrayList<FlightSchedule>();
		Flight[] flights = restTemplate.getForObject(
				"http://localhost:8089/flightsByLocation?src={src}&destination={destination}&upto={departureDate}",
				Flight[].class, src, destination, departureDate);

		for (int flightCount = 0; flightCount < flights.length; flightCount++) {
			FlightSchedule flightSchedule = new FlightSchedule();
			flightSchedule.setFlight(flights[flightCount]);
			flightSchedule.setTotalDelay(flights[flightCount].getArrivalDelayInMinutes()
					+ flights[flightCount].getDepartureDelayInMinutes()
					+ flights[flightCount].getCarrierDelayInMinutes() + flights[flightCount].getDiversionArrivalDelay()
					+ flights[flightCount].getLateAirportDelayInMinutes() + flights[flightCount].getNASDelayInMinutes()
					+ flights[flightCount].getSecurityDelayInMinutes()
					+ flights[flightCount].getWeatherDelayInMinutes());
			flightSchedule.setCancelled(flights[flightCount].isCancelled());
			flightScheduleList.add(flightSchedule);
		}
		return flightScheduleList;
	}

}
