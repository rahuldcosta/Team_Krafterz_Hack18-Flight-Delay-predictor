package extraction.domain;


public class FlightSchedule {
	Flight flight;
	int totalDelay;
	boolean isCancelled;
	
	public boolean isCancelled() {
		return isCancelled;
	}
	public void setCancelled(boolean isCancelled) {
		this.isCancelled = isCancelled;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public int getTotalDelay() {
		return totalDelay;
	}
	public void setTotalDelay(int delay) {
		this.totalDelay = delay;
	}
	
	

}
