package extraction.domain;

import java.time.LocalDate;
import java.util.Date;

public class Flight {

	private String carrierCode;
	private String FlightNo;
	private String cancelledCode;
	private Date departureDate;
	private int departureDelayInMinutes;
	private int arrivalDelayInMinutes;
	private int carrierDelayInMinutes;
	private int weatherDelayInMinutes;
	private int NASDelayInMinutes;
	private int SecurityDelayInMinutes;
	private int lateAirportDelayInMinutes;
	private boolean cancelled;
	private int diversionArrivalDelay;
	private String src;
	private String destination;


	public String getFlightNo() {
		return FlightNo;
	}

	public void setFlightNo(String flightNo) {
		FlightNo = flightNo;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public int getDepartureDelayInMinutes() {
		return departureDelayInMinutes;
	}

	public void setDepartureDelayInMinutes(int departureDelayInMinutes) {
		this.departureDelayInMinutes = departureDelayInMinutes;
	}

	public int getArrivalDelayInMinutes() {
		return arrivalDelayInMinutes;
	}

	public void setArrivalDelayInMinutes(int arrivalDelayInMinutes) {
		this.arrivalDelayInMinutes = arrivalDelayInMinutes;
	}

	public int getCarrierDelayInMinutes() {
		return carrierDelayInMinutes;
	}

	public void setCarrierDelayInMinutes(int carrierDelayInMinutes) {
		this.carrierDelayInMinutes = carrierDelayInMinutes;
	}

	public int getWeatherDelayInMinutes() {
		return weatherDelayInMinutes;
	}

	public void setWeatherDelayInMinutes(int weatherDelayInMinutes) {
		this.weatherDelayInMinutes = weatherDelayInMinutes;
	}

	public int getNASDelayInMinutes() {
		return NASDelayInMinutes;
	}

	public void setNASDelayInMinutes(int nASDelayInMinutes) {
		NASDelayInMinutes = nASDelayInMinutes;
	}

	public int getSecurityDelayInMinutes() {
		return SecurityDelayInMinutes;
	}

	public void setSecurityDelayInMinutes(int securityDelayInMinutes) {
		SecurityDelayInMinutes = securityDelayInMinutes;
	}

	public int getLateAirportDelayInMinutes() {
		return lateAirportDelayInMinutes;
	}

	public void setLateAirportDelayInMinutes(int lateAirportDelayInMinutes) {
		this.lateAirportDelayInMinutes = lateAirportDelayInMinutes;
	}

	public boolean isCancelled() {
		return cancelled;
	}

	public void setCancelled(boolean canceclled) {
		this.cancelled = canceclled;
	}

	public int getDiversionArrivalDelay() {
		return diversionArrivalDelay;
	}

	public void setDiversionArrivalDelay(int diversionArrivalDelay) {
		this.diversionArrivalDelay = diversionArrivalDelay;
	}

	public void setCancelledCode(String cancelledCode) {
		this.cancelledCode = cancelledCode;	
	}
	 public String getCancelledCode(){
		 return cancelledCode;
	 }

}
