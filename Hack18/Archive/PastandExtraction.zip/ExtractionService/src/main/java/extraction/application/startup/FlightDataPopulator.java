package extraction.application.startup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import extraction.domain.Flight;

public class FlightDataPopulator {

	public static final String delimiter = ",";

	public static List<Flight> read(String src, String destination) {
		List<Flight> flightData = new ArrayList<>();
		List<String> csvFileList = new ArrayList<>();
		
	//	csvFileList.add("C:/Users/sg0224786/Desktop/scheduleData/one.csv");
		csvFileList.add("C:/Users/sg0224786/Desktop/scheduleData/nov2017.csv");
		csvFileList.add("C:/Users/sg0224786/Desktop/scheduleData/dec2017.csv");
		Flight flight;


for(String csvFile : csvFileList){
	int count =  0;
		try {
			File file = new File(csvFile);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);

			String line = "";
			String[] tempArr = new String[21];
			if(count == 0 ){
				line = br.readLine();
				count++;
			}
			while ((line = br.readLine()) != null) {
				flight = new Flight();
				tempArr = line.split(delimiter,-1);

				if(tempArr[3].equalsIgnoreCase(src) && tempArr[5].equalsIgnoreCase(destination)){
				flight.setFlightNo(tempArr[2]);
				flight.setCarrierCode(tempArr[1]);
				flight.setSrc(tempArr[3]);
				flight.setDestination(tempArr[5]);
				flight.setDepartureDate(new SimpleDateFormat("MM/dd/yyyy").parse(tempArr[0]));
				flight.setDepartureDelayInMinutes(!(tempArr[9].equals(""))?Integer.parseInt(tempArr[9]):0);
				flight.setArrivalDelayInMinutes(!(tempArr[12].equals(""))?Integer.parseInt(tempArr[12]):0);
				flight.setCarrierDelayInMinutes(!(tempArr[16].equals(""))?Integer.parseInt(tempArr[16]):0);
				flight.setWeatherDelayInMinutes(!(tempArr[17].equals(""))?Integer.parseInt(tempArr[17]):0);
				flight.setNASDelayInMinutes(!(tempArr[18].equals(""))?Integer.parseInt(tempArr[18]):0);
				flight.setSecurityDelayInMinutes(!(tempArr[19].equals(""))?Integer.parseInt(tempArr[19]):0);
				flight.setLateAirportDelayInMinutes(!(tempArr[20].equals(""))?Integer.parseInt(tempArr[20]):0);
				flight.setCancelled(Integer.parseInt(tempArr[13])==1?true:false);
				flight.setCancelledCode(tempArr[14].equals("A")?"Carrier Delay":tempArr[14].equals("B")?"Weather":tempArr[14].equals("C")?"National Air System": tempArr[14].equals("D")?"Security":"");
				flight.setDiversionArrivalDelay(!(tempArr[21].equals(""))?Integer.parseInt(tempArr[21]):0);

				flightData.add(flight);
				}
			}
			br.close();
			// for (Flight tempStr : flightData) {
			// System.out.println(tempStr.getFlightNo()+" || "
			// +tempStr.getCarrier() + " || " + tempStr.getSrc()+" ||
			// "+tempStr.getDestination()+" || "+ tempStr.getDepartureDate()+ "
			// || "+tempStr.getIntendedDepartureTime()+" ||
			// "+tempStr.getActualDepartureTime());
			//
			//
			// }
			// System.out.println();
		
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
		return flightData;
	}

}
