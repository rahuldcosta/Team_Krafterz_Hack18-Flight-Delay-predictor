package extraction.rest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import extraction.application.startup.FlightDataPopulator;
import extraction.domain.Flight;

@Named
@Path("/")
public class FlightRest {	
	
	//private static List<Flight> flights = FlightDataPopulator.read("C:/Users/sg0224786/Desktop/scheduleData.csv");
	
	@GET
	@Path("flightsByLocation")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Flight> getFlightsOnCityPairs(@QueryParam("src") String src, @QueryParam("destination") String destination, @QueryParam("upto") String departureDate ) throws ParseException {
		List<Flight> listOfFlights = new ArrayList<>();
		List<Flight> flights = FlightDataPopulator.read(src,destination);

		for (Flight flight : flights) {
		//	flight.getSrc().equalsIgnoreCase(src) && flight.getDestination().equalsIgnoreCase(destination) && 
			if (flight.getDepartureDate().compareTo(new SimpleDateFormat("MM/dd/yyyy").parse(departureDate))>=0 )
				listOfFlights.add(flight);
		}
		return listOfFlights;
	}
//
//	@GET
//	@Path("flightsBy")
//	@Produces(MediaType.APPLICATION_JSON)
//	public List<Flight> getFlight(@QueryParam("carrierCode") String carrierCode) {
//		// this method will only return all the schedule data for a particular
//		// carrier.
//		// for a particular src-destination compute else where
//		List<Flight> listOfAllFlights = new ArrayList<>();
//		for (Flight flight : flights) {
//			if (flight.getCarrier().equalsIgnoreCase(carrierCode))
//				listOfAllFlights.add(flight);
//		}
//		return listOfAllFlights;
//	}
//
//@GET
//@Path("allFlights")
//@Produces(MediaType.APPLICATION_JSON)
//public List<Flight> getAllFlights() {
//return flights;
//}

}
