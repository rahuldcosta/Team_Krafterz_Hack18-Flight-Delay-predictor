package com.hack18.delay.ui.DelayUIApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DelayUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DelayUiApplication.class, args);
	}
}
