package extraction.rest;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import extraction.application.startup.FlightDataPopulator;
import extraction.domain.Flight;

@Named
@Path("/")
public class FlightRest {

    // private List<Flight> flights = FlightDataPopulator.read("C:/Users/sg0224786/Desktop/scheduleData.csv");
    private static List<Flight> flights = FlightDataPopulator.read("C:/Users/sg0224785/Desktop/scheduleData.csv");

    @GET
    @Path("flightsByLocation")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Flight> getFlightsOnCityPairs(@QueryParam("src") String src,
                                              @QueryParam("destination") String destination) {
        List<Flight> listOfFlights = new ArrayList<>();
        for (Flight flight : flights) {
            if (flight.getSrc().equalsIgnoreCase(src) && flight.getDestination().equalsIgnoreCase(destination))
                listOfFlights.add(flight);
        }
        return listOfFlights;
    }

    @GET
    @Path("flightsBy")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Flight> getFlight(@QueryParam("carrierCode") String carrierCode) {
        // this method will only return all the schedule data for a particular
        // carrier.
        // for a particular src-destination compute else where
        List<Flight> listOfAllFlights = new ArrayList<>();
        for (Flight flight : flights) {
            if (flight.getCarrier().equalsIgnoreCase(carrierCode))
                listOfAllFlights.add(flight);
        }
        return listOfAllFlights;
    }

    @GET
    @Path("allFlights")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Flight> getAllFlights() {
        return flights;
    }

}
