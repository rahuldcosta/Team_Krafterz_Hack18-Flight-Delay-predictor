package extraction.application.startup;

import java.text.ParseException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	
public static void main(String[] args) throws ParseException {
//	String csvFile = "C:/Users/sg0224786/Desktop/scheduleData.csv";
//	FlightDataPopulator.read(csvFile);
	SpringApplication.run(Application.class, args);
	
}
}