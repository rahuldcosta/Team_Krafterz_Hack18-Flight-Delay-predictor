package extraction.application.startup;
	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileReader;
	import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import extraction.domain.Flight;
public class FlightDataPopulator {

		public static final String delimiter = ",";

		public static List <Flight> read(String csvFile) {
			List <Flight> flightData = new ArrayList<>();

			try {
				File file = new File(csvFile);
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);

				String line = "";
				Flight flight ;
				String[] tempArr;
				while ((line = br.readLine()) != null) {
					flight = new Flight();
					tempArr = line.split(delimiter);
					flight.setFlightNo(tempArr[0]);
					flight.setCarrier(tempArr[1]);
					flight.setSrc(tempArr[2]);
					flight.setDestination(tempArr[3]);
					flight.setDepartureDate(new SimpleDateFormat("dd/MM/yyyy").parse(tempArr[4]));
					flight.setIntendedDepartureTime(new Timestamp(new SimpleDateFormat("HH:mm:ss",Locale.ENGLISH).parse(tempArr[5]).getTime()));//instead of date put your converted date
					flight.setActualDepartureTime(new Timestamp(new SimpleDateFormat("HH:mm:ss",Locale.ENGLISH).parse(tempArr[6]).getTime()));//instead of date put your converted date
					flightData.add(flight);
				}
				br.close();
//				for (Flight tempStr : flightData) {
//					System.out.println(tempStr.getFlightNo()+" || " +tempStr.getCarrier() + " || " + tempStr.getSrc()+" ||  "+tempStr.getDestination()+" || "+ tempStr.getDepartureDate()+ " || "+tempStr.getIntendedDepartureTime()+" ||  "+tempStr.getActualDepartureTime());
//					
//					
//				}
//				System.out.println();

			} catch (IOException ex) {
				ex.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
return flightData;
		}

}
