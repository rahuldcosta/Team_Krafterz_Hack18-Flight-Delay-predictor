package extraction.domain;

import java.util.Date;

public class Flight {

	private String carrierCode;
	private String FlightNo;
	private Date departureDate;
	private Date intendedDepartureTime;
	private Date actualDepartureTime;
	private String src;
	private String destination;
	private String arrivalTerminal;
	private String departureTerminal;
	//private Date delay;

	public String getCarrier() {
		return carrierCode;
	}

	public void setCarrier(String carrier) {
		this.carrierCode = carrier;
	}

	public String getFlightNo() {
		return FlightNo;
	}

	public void setFlightNo(String flightNo) {
		FlightNo = flightNo;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getIntendedDepartureTime() {
		return intendedDepartureTime;
	}

	public void setIntendedDepartureTime(Date intendedDepartureTime) {
		this.intendedDepartureTime = intendedDepartureTime;
	}

	public Date getActualDepartureTime() {
		return actualDepartureTime;
	}

	public void setActualDepartureTime(Date actualDepartureTime) {
		this.actualDepartureTime = actualDepartureTime;
	}

	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getArrivalTerminal() {
		return arrivalTerminal;
	}

	public void setArrivalTerminal(String arrivalTerminal) {
		this.arrivalTerminal = arrivalTerminal;
	}

	public String getDepartureTerminal() {
		return departureTerminal;
	}

	public void setDepartureTerminal(String departureTerminal) {
		this.departureTerminal = departureTerminal;
	}

}
