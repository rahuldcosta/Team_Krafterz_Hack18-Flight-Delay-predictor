package com.howtodoinjava.app.controller;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.QueryParam;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

    @Inject
    private RestTemplate restTemplate;

    
    @RequestMapping("/")
    public String home(Map<String, Object> model) throws JSONException {
        model.put("message", "Welcome to HOme Page");
        // model.put("message", "HowToDoInJava Reader !!");
        return "home";
    }
    
    
    
    @RequestMapping("/showdelayfromCSV")
    public String showdelayfromcsv(Map<String, Object> model) throws JSONException {
        String text;
        text = restTemplate.getForObject(
                "http://localhost:8090/showDelayForFlightsFromCSV", String.class);
        JSONObject jsonObject = new JSONObject(text);
        model.put("delayPredictionsForCarriers", jsonObject);
        // model.put("message", "HowToDoInJava Reader !!");
        return "index";
    }

    @RequestMapping("/showavgcarrierdelay")
    public String avgcarrierdelay(Map<String, Object> model) throws JSONException {
        getAvgDelayforCarriers(model);
        return "avgdelay";
    }
    

    @RequestMapping("/availpage")
    public String getAvailPage(Map<String, Object> model) throws JSONException {
          
        //do call to finddelay
        //do call to pasttrend
        getPredictedDelayforCarriers(model);
        getAvgDelayforCarriers(model);
        
        return "availpage";
    }

    private void getAvgDelayforCarriers(Map<String, Object> model) throws JSONException {
        String s;
        s = restTemplate.getForObject(
                "http://localhost:8090/findAvgDelayforCarriers", String.class);
        
        JSONObject jsonObject = new JSONObject(s);
        model.put("findAvgDelayforCarriersObject", jsonObject);
    }
    
    private void getPredictedDelayforCarriers(Map<String, Object> model) throws JSONException {
        String s;
        //http://localhost:8090/showDelayForFlightsFromUI?month=12&dayofweek=2&origin=DFW&dest=ORD&distance=2300&isdelay=NO&carrierslist=UA,QF,NK
        s = restTemplate.getForObject(
                "http://localhost:8090/showDelayForFlightsFromUI?month=12&dayofweek=2&origin=DFW&dest=ORD&distance=2300&isdelay=YES&carrierslist=UA,QF,NK,AA", String.class);
        
        JSONObject jsonObject = new JSONObject(s);
        model.put("delayPredictionsForCarriers", jsonObject);
    }
    
    
    @GET
    @RequestMapping("/next")
    public String getFlightsOnCityPairs(@QueryParam("src") String src,
                                        @QueryParam("carrier") String carrier,Map<String, Object> model) {
                                       
        model.put("message", "You are in new page data is coming !!"+ src+ carrier);
        return "next";
    }

}
