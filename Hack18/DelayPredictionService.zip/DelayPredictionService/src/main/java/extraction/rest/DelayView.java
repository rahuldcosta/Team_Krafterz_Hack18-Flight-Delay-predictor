package extraction.rest;

import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import extraction.domain.FlightDataEntry;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import extraction.application.startup.FlightDataPopulator;

@Named
@Path("/")
public class DelayView {
    private RConnection connection = null;

    @GET
    @Path("callR")
    @Produces(MediaType.TEXT_PLAIN)
    public String getAllFlights() {
        int sum = 0;
//        try {
//            connection = new RConnection();
//            int num1 = 10;
//            int num2 = 20;
//            sum = connection.eval("myAdd(" + num1 + "," + num2 + ")").asInteger();
//        } catch (RserveException e) {
//            e.printStackTrace();
//        } catch (REXPMismatchException e) {
//            e.printStackTrace();
//        } finally {
//            connection.close();
//        }

        return "The sum is=" + sum;
    }
//
//    @GET
//    @Path("findAvgDelayforCarriers")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String findaveragedelayforcarriers(@QueryParam("date") String date) {
//        String avgdelayresponse = "";
//        try {
//            connection = new RConnection();
//            avgdelayresponse = connection.eval("findaveragedelayforcarriers(\"" + date + "\")").asString();
//        } catch (RserveException | REXPMismatchException e) {
//            e.printStackTrace();
//        } finally {
//            connection.close();
//        }
//        System.out.println(avgdelayresponse + "   <- found avg delay json");
//        return avgdelayresponse;
//
//    }
//
//    @GET
//    @Path("delayPredForAirlines")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String delayPredForAirlines(@QueryParam("date") String date,
//                                       @QueryParam("origin") String origin, @QueryParam("dest") String dest,
//                                       @QueryParam("distance") String distance,
//
//                                       @QueryParam("carrier") String carrier) {
//        String avgdelayresponse = "";
//        try {
//            connection = new RConnection();
//            avgdelayresponse =
//                    connection.eval(
//                            "delaypredictionforairlines(\"" + carrier + "\",\"" + date + "\",\"" + origin + "\",\""
//                                    + dest + "\",\"" + distance + "\")").asString();
//        } catch (RserveException | REXPMismatchException e) {
//            e.printStackTrace();
//        } finally {
//            connection.close();
//        }
//        System.out.println(avgdelayresponse + "   <- found avg delay json");
//        return avgdelayresponse;
//
//    }
//
//    @GET
//    @Path("showDelayForFlightsFromCSV")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String loadFlightsFromCSV() {
//        List<FlightDataEntry> flightsFromCSV = new ArrayList<FlightDataEntry>();
//        flightsFromCSV = FlightDataPopulator.read("C:/Hack18/Data/FlightsFromUI.csv");
//        return predictDelayForFlights(flightsFromCSV);
//    }
//
//    @GET
//    @Path("showDelayForFlightsFromUI")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String loadFlightsFromUI(@QueryParam("month") String month, @QueryParam("dayofweek") String dayofweek,
//                                    @QueryParam("origin") String origin, @QueryParam("dest") String dest,
//                                    @QueryParam("distance") String distance,
//                                    @QueryParam("isdelay") String isdelay,
//                                    @QueryParam("carrierslist") String carrierslist) {
//        System.out.println(month + "|||||" + dayofweek + "|||||" + origin + "|||||" + dest + "|||||" + distance
//                + "|||||" + isdelay + "|||||" + carrierslist);
//        List<FlightDataEntry> flightsFromUI = new ArrayList<FlightDataEntry>();
//        String[] carriers = carrierslist.split(",");
//
//        for (String carrier : carriers) {
//            FlightDataEntry f =
//                    new FlightDataEntry("\"" + month + "\"", "\"" + dayofweek + "\"", "\"" + carrier + "\"", "\""
//                            + origin + "\"", "\"" + dest + "\"", "\"" + distance + "\"", "\"" + isdelay + "\"");
//
//            flightsFromUI.add(f);
//        }
//        return predictDelayForFlights(flightsFromUI);
//    }
//
//    private String predictDelayForFlights(List<FlightDataEntry> flights) {
//        String delayValues = "";
//        try {
//            connection = new RConnection();
//            connection.eval("resetTestingObject()");
//            for (FlightDataEntry tempflight : flights)
//            {
//                connection.eval("populateTestingDataObject(" + tempflight.getMonth() + "," + tempflight.getDayOfWeek()
//                        + "," + tempflight.getCarriercode() + "," + tempflight.getOrigin() + "," + tempflight.getDest()
//                        + "," + tempflight.getDistance() + "," + tempflight.getDelay() + ")");
//            }
//            delayValues = connection.eval("findisDelayForCarriers()").asString();
//            System.out.println(delayValues + "   <- Predictions for Carriers");
//        } catch (RserveException e) {
//            e.printStackTrace();
//        } catch (REXPMismatchException e) {
//            e.printStackTrace();
//        } finally {
//            connection.close();
//        }
//
//        return delayValues;
//    }

}
