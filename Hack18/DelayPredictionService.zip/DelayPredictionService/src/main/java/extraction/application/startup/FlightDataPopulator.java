package extraction.application.startup;
	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileReader;
	import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import extraction.domain.FlightDataEntry;
public class FlightDataPopulator {

		public static final String delimiter = ",";

		public static List <FlightDataEntry> read(String csvFile) {
			List <FlightDataEntry> flightData = new ArrayList<>();

			try {
				File file = new File(csvFile);
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);

				String line = "";
				FlightDataEntry flight ;
				String[] tempArr;
				while ((line = br.readLine()) != null) {
				    tempArr = line.split(delimiter);
					flight = new FlightDataEntry(tempArr[0], tempArr[1], tempArr[2], tempArr[3], tempArr[4], tempArr[5], tempArr[6]);
					flightData.add(flight);
				}
				br.close();

			} catch (IOException ex) {
				ex.printStackTrace();
			}
return flightData;
		}

}
